
4+5
6-2


# Arithmetic Operator 
5+3  # + for addition
5-3  # - for subtraction
5*3  # * for multiplication
6/2  # / for division

6^2 # ^ for exponentiation 
6**2 # ** is same as ^

17/5 
17%/%5 # for quotient 
17%%5 # for remainder 


# Assignment Operator 

# left assignment operators 
a1=4
a1*3

a2<-7
a2+5

a3<<-8

# Right assignment operators
6->a4

9->>a5

-5->a6

a7<--2
a8 <- -5


# Relational (Conditional) Operator
5==5
5==6

5!=6

5<6
6<=5

7>7
7>=7

# Logical (Boolean) operators 
TRUE & TRUE
TRUE & FALSE
F & T

T|T
T|F
F|T

!TRUE
!FALSE

(4>7) | (6==6)


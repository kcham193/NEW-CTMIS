
###### R VECTORS : 08-DEC-2023 ##########
rm(list = ls())
# Single Element Vector Creation 
# Logical Type 
v1 <- TRUE 
class(v1)
print(v1)

v2 <- FALSE;class(v2);print(v2)
v3 <- F;class(v3);print(v3)

# Integer data type
v4 <- 5;class(v4);print(v4)
v5 <- 5L;class(v5);print(v5)
v6 <- 5.2L;class(v6);print(v6)


# numeric data type
v7 <- 5;class(v7);print(v7)
v8 <- 7.5;class(v8);print(v8)


# Complex data type 
v9 <- 3+4i;class(v9);print(v9)
v10 <- 10-2.5i;class(v10);print(v10)


# Character (Text or String) Data Type
v11 <- "EASTC";class(v11);print(v11)
v12 <- "5";class(v12);print(v12)
v13 <- "TRUE";class(v13);print(v13)


# Multiple elements vector creation 
v14 <- T,F,F,T
v15 <- c(T,F,F,T);class(v15);print(v15)

# Vector Creation by c() function
v16 <- c(T,T,F,T,F);v16;class(v16) #for logical vector
v17 <- c(3L,10L,-31L,15L);v17;class(v17) #for integer vector
v18 <- c(5,12.7,14,59.3);v18;class(v18) #for numeric vector
v19 <- c(2+3i,4-6i,8-1i);v19;class(v19) #for complex vector
v20 <- c("EASTC","UDSM","ARU");v20;class(v20) # for character vector

# Create a vector by rep() function
# repeat values 
v21 <- c(2,2,2,2,5,5,5,5,9,9,9,9);v21
v22 <- rep(c(2,5,9),each=4);v22
v23 <- rep(c(2,5,9),each=15);v23

# repeat sequence 
v24 <- c(2,5,9,2,5,9,2,5,9,2,5,9);v24
v25 <- rep(c(2,5,9),times=4);v25
v26 <- rep(c(2,5,9),times=15);v26

# different repeat for each value
v27 <- c(2,2,2,5,5,9,9,9,9,9,9);v27
v28 <- rep(c(2,5,9),times=c(3,2,6));v28
v29 <- rep(c(2,5,9),times=c(10,7,15));v29


# Full colon (:) function for numeric vector only
v30 <- c(1,2,3,4,5,6,7,8,9,10);v30
v31 <- 1:10;v31
v32 <- 50:100;v32


# seq() function for AP series 
v33 <- c(1,4,7,10,13,16,19);v33
v34 <- seq(from=1,to=19,by=3);v34;length(v34)
v35 <- seq(from=1,to=19,by=2);v35
v36 <- seq(1,19,3);v36

v34 <- seq(from=1,to=19,by=3);v34;length(v34)
v37 <- seq(from=1,by=3,length=7);v37

v38 <- seq(30,10,-2);v38
v39 <- seq(30,10,-2.5);v39


#### VECTOR MANIPULATION #####
v40 <- c(23,-41,65,11,44,32,9);v40
v41 <- c("EASTC","UDSM","ARU","UDOM","IFM");v41

## Extract (access) vector elements from vector 
v40[3] # extract element in 3rd position
v40;v42 <- v40[c(1,4,6)];v42
v40;v43 <- v40[1:4];v43
v40;v44 <- v40[seq(1,7,2)];v44
v41[4]


## Drop vector elements from vector, use -ve in []
v40;v40[-3] # drop element in 3rd position
v40;v45 <- v40[-c(1,4,6)];v45
v40;v46 <- v40[-(1:4)];v46
v40;v47 <- v40[-seq(1,7,2)];v47


## To change (update) vector elements
v40
v40;v40[4] <- 15;v40
v41;v41[2] <- "Mzumbe";v41

v40;v40[c(2,5)] <- c(20,45);v40

## To add vector elements
v40;length(v40)

v40;v40[8] <- 50;v40
v40;v40[10] <- 70;v40
v40;v40[11:13] <- c(17,25,31);v40


## Sorting Elements 
v40;v42 <- sort(v40);v42 # by ascending order 
v40;v43 <- sort(v40,decreasing = T);v43 # by descending order 













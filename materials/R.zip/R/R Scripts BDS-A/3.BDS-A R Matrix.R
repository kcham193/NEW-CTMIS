
### MATRIX : 15-12-2023 

# Matrix Creation 

# Elements picked row wise 
M1 <- matrix(c(1,4,-2,0,6,8,1,2,3),nrow = 3,ncol = 3,byrow = T);M1
a1 <- c(1,4,-2,0,6,8,1,2,3)
M2 <- matrix(a1,nrow = 3,ncol = 3,byrow = T);M2
M3 <- matrix(a1,3,3,T);M3

# Elements picked column wise (default)
a2 <- c(1,0,1,4,6,2,-2,8,3)
M4 <- matrix(a2,nrow = 3,ncol = 3,byrow = F);M4
M5 <- matrix(a2,nrow = 3,ncol = 3);M5 
M6 <- matrix(a2,3,3);M6 
M7 <- matrix(a2,3);M7

a3 <- c(10,4,7,6,12,15)
M8 <- matrix(a3,2,3);M8

a4 <- c(1,0,1,4,6,2)
M9 <- matrix(a4,3,2);M9
class(M9)

dim(M9);dim(M8);dim(M7)

# Create matrix by dimension function
#NB: you must pick your elements column wise
M7b <- a2;M7b
dim(M7b) <- c(3,3);M7b

M9b <- a4;M9b
dim(M9b) <- c(3,2);M9b

# Important tips in Matrix 
M7b;length(M7b);dim(M7b);nrow(M7b);ncol(M7b)
M9b;length(M9b);dim(M9b);nrow(M9b);ncol(M9b)

## Accessing Matrix Elements 
M7
M7[2,3]
M7[1,2]

## Access more than one element in row
M7[2,c(1,3)]

## Access more than one element in column
M7[c(1,3),2]

## Access more than one element in row and column
M7;M10 <- M7[c(1,3),c(1,3)];M10

# Access Entire row 
M7;M7[2,]
M7;M7[c(1,3),]

# Access Entire Column  
M7;M7[,3]
M7;M7[,c(2,3)]

# Drop row/ column 
M7
M7;M7[,c(2,3)]
M7;M7[,-1]

M7;M10 <- M7[c(1,3),c(1,3)];M10
M7;M11 <- M7[-c(1,3),-c(1,3)];M11 # not recommended 


# Update/ change vector elements 
M7
M7[2,1] <- -5;M7
M7[c(1,3),3] <- c(10,15);M7

M7[3,] <- 20:22;M7

### cbind and rbind 
M8
M12 <- matrix(1:9,3,3);M12
M13 <- matrix(1:4,2,2);M13

## cbind (same number of rows)
M8;nrow(M8)
M13;nrow(M13)
M14 <- cbind(M8,M13);M14;dim(M14)

M8
cbind(M8,c(25,30))

## rbind (same number of columns)
M8;ncol(M8)
M12;ncol(M12)
M15 <- rbind(M8,M12);M15;dim(M15)

rbind(M8,c(1,6,11))


### Matrix Arithmetic Operators by R
#2 by 2 matrices
matrix(c(10, 5,8, 12), 2)->A1;A1
matrix(c(5, 15,3, 6), 2)->A2;A2

#2 by 3 matrices
matrix(c(10, 5,8, 12,5,9), 2)->B1;B1
matrix(c(5, 15,3, 6,-4,7), 2)->B2;B2

#3 by 2 matrices
matrix(c(14, 5,8, 12,5,9), 3)->C1;C1
matrix(c(5, 15,17, 6,-4,7), 3)->C2;C2

#3 by 3 matrices
matrix(c(14, 5,8, 12,5,9,1,2,3), 3)->D1;D1
matrix(c(5, 15,17, 6,-4,7,7,8,9), 3)->D2;D2

# Add matrices 
B1;B2;B3 <- B1+B2;B3

# Subtract matrices 
B1;B2;B4 <- B1-B2;B4

## Matrix Multiplication 

# Scalar multiplication 
A1
A1*5;5*A1
A1;A1+5

# element-wise multiplication  (equal dimension)
A1;A2;A5 <- A1*A2;A5



##### ITRODUCTION : 27-10-2023 ##########

## Arithmetic Operators 
9+4 # for addition use + sign 
9-4 # for subtraction use - sign 
9*4 # for multiplication use * sign 
9/4 # for division use / sign 

9^2 # for exponent use ^ sign 
9**2 # ** is same as ^

9/4 # for division use / sign 
9%/%4 # for quotient use %/% sign
9%/%2 

9%%4 # for remainder use %% sign
9%%5

## Assignment Operators

# left assignment  operators
a1=6
a1^4

a2<-8 #my 1st favorite #short cut alt+ -
a2^2


a3<<-9

# right assignment  operators
4->a4 #my 2nd favorite
a5->6 #invalid 

3->>a5



## Conditional Operators
5==6
6==6

5<6
5<5
5<=5

5>6
5>=5

5!=6

## Logical Operators
TRUE & TRUE
TRUE & FALSE

TRUE | FALSE

!TRUE
!FALSE

(6==5) & (4<6)
(6==5) | (4<6)









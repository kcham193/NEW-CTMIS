
### VECTOR : 27-10-2023 

## VECTOR CREATION 

#Single element vector creation 

v1 <- TRUE;class(v1) #for logical vector
v2 <- 4L;class(v2) # for integer vector 
v3 <- 4;class(v3) # for numeric vector 
v4 <- 3+6i;class(v4) # for complex vector 
v5 <- "eastc";class(v5)  # for character vector 
length(v5)

# Multiple elements vector creation 

# by concatenate: c() function
v6 <- c(TRUE,FALSE, TRUE);print(v6);class(v6);length(v6)
v7 <- c(1L,5L,8L,-3L);print(v7);class(v7);length(v7)
v8 <- c(1.5,7,-3.4);print(v8);class(v8);length(v8)
v9 <- c(3-5i,6+2i);print(v9);class(v9);length(v9)
v10 <- c("eastc","udsm","ardhi");print(v10);class(v10);length(v10)


# by repeat : rep() function 
v11 <- c(1,1,1,1,4,4,4,4,9,9,9,9);print(v11)
v12 <- rep(c(1,4,9),each=4);print(v12) # for repeating values 
v13 <- rep(c(1,4,9),each=15);print(v13)


v14 <- c(1,4,9,1,4,9,1,4,9,1,4,9);print(v14)
v15 <- rep(c(1,4,9),times=4);print(v15) # for repeating sequence 

v16 <- c(1,1,1,1,1,4,4,4,9,9,9,9,9,9,9,9);print(v16)
v15 <- rep(c(1,4,9),times=c(5,3,8));print(v15) # for value independent repetition 


## by full colon function (only for numeric values)
v17 <- c(1,2,3,4,5,6,7,8,9,10);print(v17)
v18 <- 1:10;print(v18)
v19 <- 1:100;print(v19)

## by sequence: seq() function (only for numeric values)
v20 <- c(1,4,7,10,13,16,19,22);print(v20)
v21 <- seq(from=1,to=22,by=3);print(v21)
v22 <- seq(from=1,to=50,by=3);print(v22)
v23 <- seq(1,22,3);print(v23)
v24 <- seq(from=1,by=3,length=8);print(v24)


### VECTOR MANIPULATION : 08-DEC-2023 ########
rm(list = ls()) # to clear all objects in memory 

v1 <- c(45,21,15,67,32,11,30)
v2 <- c("BDS","BOS","BASE","MOS")

# Access (extract) one element 
v1[4] # access 4th element
v2[2] # access 2nd element 

# Access (extract) at least two elements use c function
v1
v1[c(2,5)]
v3 <- v1[c(2,5)];print(v3)
v4 <- v2[c(1,4)];print(v4)

# To drop element use -ve sign before element position
v1;v2

v5 <- v1[-2];print(v5) # drop the 2nd element from v1
v1;v1[c(-2,-5)];v1[-c(2,5)]

# To update (change) vector element 
v1;v2

v1[3] <- 25;v1
v2[4] <- "MAS";v2

length(v1)

v1[c(1,4)] <- c(80,95);v1
v1[seq(1,7,2)] <- 9;v1


## Add element value in vector 
v1;v2

v1[8] <- 55;v1
v1[10] <- 67;v1
v1[11:13] <- c(71,35,22);v1
v2[c(5,6)] <-c("MOS","BBSE");v2 

## Sort Vector Elements 
v1;v2

# sort by ascending order
v5 <- sort(v1);v1;v5 
v6 <- sort(v2);v2;v6

# sort by descending order 
v7 <- sort(v1,decreasing = TRUE);v1;v7 
v8 <- sort(v2,decreasing = TRUE);v2;v8

# Arithmetic application 
v11<-c(3,8,4,5,0,11)
v12<-c(4,11,0,8,1,2)

v11;v12;v11+v12 # for addition 
v11;v11+10
v11;v12;v11-v12 # for subtraction
v11;v12;v11*v12 # for multiplication
v11;v11*5
v11;v12;v11/v12 # for division
v11;v11^2;v11**2

# Descriptive Statistics from Numeric Vector 
v1

mean(v1)
mean(v7)
mean(v1,na.rm = T)
is.na(v1);is.na(v7)

median(v1);median(v1,na.rm = T);median(v7)

min(v1,na.rm = T);max(v1,na.rm = T)

summary(v1) # for several statistics


### Measures of position (Quantiles)
median(v1,na.rm = T)

# quartile 
quantile(v1,na.rm = T)
quantile(v1,na.rm = T,probs = c(0.25,0.5,0.75))


# Decile 
quantile(v1,na.rm = T,probs = seq(0.1,0.9,0.1))

# Percentile 
quantile(v1,na.rm = T,probs = seq(0.01,0.99,0.01))
quantile(v1,na.rm = T,probs = c(0.12,.35,.49,.91))

## Maximum and Minimum
max(v1,na.rm = T) # for maximum value
min(v1,na.rm = T) # for minimum value

## variance and Standard deviation 
var(v1,na.rm = T)
sd(v1,na.rm = T)

## Inter-quartile range 
IQR(v1,na.rm = T)


## Covariance and Correlation 
v2 <- c(32,56,11,-20,41)
v3 <- c(35,44,78,10,5)

cov(v2,v3)
cor(v2,v3)


## Summation and Product 
v2;sum(v2);prod(v2)
v3;sum(v3);prod(v3)

## Cumulative Summation and Product 
v2;cumsum(v2);cumprod(v2)
v3;cumsum(v3);cumprod(v3)


### MATHEMATICAL FUNCTIONS

# Absolute function 
v2;abs(v2)

# Logarithm function
log(50) # default is natural log
log(50,base = 3)
log(50,3)
v3;v4 <- log(v3);v4

# Exponential function 
v3;v4 <- log(v3);v4
v5 <- exp(v4);v5

# Square root function 
v3;v6 <- sqrt(v3);v6
v2;v7 <- sqrt(v2);v7
v2;v8 <- sqrt(abs(v2));v8 # to ignore -ve

## Factorial and Combination 
factorial(5) # for factorial
choose(5,3) #  for combination

v3;choose(v3,5)
choose(300,100)

## Rounding numbers 
v6
v6;round(v6) # round to nearest integer 
v6;round(v6,digits = 1) 
v6;round(v6, 1)
v6;round(v6, 3)

# Solving Polynomial Equations
polyroot(c(-6,2))
as.numeric(polyroot(c(-6,2)))

polyroot(c(6,-5,1))
as.numeric(polyroot(c(6,-5,1)))

polyroot(c(-8, 2, 5, 1))
as.numeric(polyroot(c(-8, 2, 5, 1)))

v8 <- polyroot(c(-8, 2, 0, 1));v8
round(v8,2)





### MATRIX : 15-12-2023 

# MATRIX CREATION 

# Picking elements row-wise
M1 <- matrix(c(1,4,-2,0,6,8,1,2,3),nrow = 3,ncol = 3,byrow = T);M1
a1 <- c(1,4,-2,0,6,8,1,2,3)
M2 <- matrix(a1,nrow = 3,ncol = 3,byrow = T);M2
M3 <- matrix(a1,3,3,T);M3

# Picking elements column-wise (default)
a2 <- c(1,0,1,4,6,2,-2,8,3)
M4 <- matrix(a2,nrow = 3,ncol = 3,byrow = F);M4
M5 <- matrix(a2,nrow = 3,ncol = 3);M5
M6 <- matrix(a2,3,3);M6
M7 <- matrix(a2,3);M7

a3 <- c(10,4,7,6,12,15)
M8 <- matrix(a3,2,3);M8

a4 <- c(1,0,1,4,6,2)
M9 <- matrix(a4,3,2);M9

## Important Tips for R Matrix
M7;dim(M7);nrow(M7);ncol(M7);length(M7)
M8;dim(M8);nrow(M8);ncol(M8);length(M8)
M9;dim(M9);nrow(M9);ncol(M9);length(M9)

# Create matrix by dim (always pick values column-wise)
M10 <- a2;M10
dim(M10) <- c(3,3);M10

M11 <- a3;M11
dim(M11) <- c(2,3);M11

M12 <- a4;M12
dim(M12) <- c(3,2);M12

class(M12)

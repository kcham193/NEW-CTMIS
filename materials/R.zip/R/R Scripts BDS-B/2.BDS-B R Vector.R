
### VECTOR : 27-10-2023 

## VECTOR CREATION 

#Single element vector creation 

v1 <- TRUE;class(v1) #for logical vector
v2 <- 4L;class(v2) # for integer vector 
v3 <- 4;class(v3) # for numeric vector 
v4 <- 3+6i;class(v4) # for complex vector 
v5 <- "eastc";class(v5)  # for character vector 
length(v5)

# Multiple elements vector creation 

# by concatenate: c() function
v6 <- c(TRUE,FALSE, TRUE);print(v6);class(v6);length(v6)
v7 <- c(1L,5L,8L,-3L);print(v7);class(v7);length(v7)
v8 <- c(1.5,7,-3.4);print(v8);class(v8);length(v8)
v9 <- c(3-5i,6+2i);print(v9);class(v9);length(v9)
v10 <- c("eastc","udsm","ardhi");print(v10);class(v10);length(v10)


# by repeat : rep() function 
v11 <- c(1,1,1,1,4,4,4,4,9,9,9,9);print(v11)
v12 <- rep(c(1,4,9),each=4);print(v12) # for repeating values 
v13 <- rep(c(1,4,9),each=15);print(v13)


v14 <- c(1,4,9,1,4,9,1,4,9,1,4,9);print(v14)
v15 <- rep(c(1,4,9),times=4);print(v15) # for repeating sequence 

v16 <- c(1,1,1,1,1,4,4,4,9,9,9,9,9,9,9,9);print(v16)
v15 <- rep(c(1,4,9),times=c(5,3,8));print(v15) # for value independent repetition 


## by full colon function (only for numeric values)
v17 <- c(1,2,3,4,5,6,7,8,9,10);print(v17)
v18 <- 1:10;print(v18)
v19 <- 1:100;print(v19)

## by sequence: seq() function (only for numeric values)
v20 <- c(1,4,7,10,13,16,19,22);print(v20)
v21 <- seq(from=1,to=22,by=3);print(v21)
v22 <- seq(from=1,to=50,by=3);print(v22)
v23 <- seq(1,22,3);print(v23)
v24 <- seq(from=1,by=3,length=8);print(v24)


### VECTOR MANIPULATION : 07-DEC-2023 ########

# Accessing vector elements
v1 <- c(6,2,9,4,34,56,12,21,35)
v2 <- c("BDS","BOS","BBSE","BASE","MOS","MAS")

# accessing one element 
v1[3]
v2[3]

# for two or more elements use c function 
v1[c(1,4)]
v2[c(1,4)]

# to drop element use -ve sign 
v1
v1[-2]
v1[-c(1,4)]
v3 <- v1[-c(1,4)]

# to update (change) vector elements
v1
v1[6] <- 40
v1[c(2,5)] <- c(30,45)
v2[2] <- "IT"

# to add vector elements
v1
length(v1)
v1[10] <- 65
v1[12] <- 39
v1[c(13,14)] <- c(28,19)

# sort vector elements 
v1
v4 <- sort(v1);print(v4) # by descending order
v5 <- sort(v1,decreasing=T);print(v5) # by descending order


# MISSING VALUE (NA)
v1
mean(v1)
mean(v4)
mean(v1,na.rm = T)

# Arithmetic application
v6<-c(3,8,4,5,0,11)
v7<-c(4,11,0,8,1,2)
print(v6);print(v7);v6+v7


# Measures of position (Quantiles)
v4
median(v4)

# for quartiles
quantile(v4)
quantile(v4,probs = c(0.25,0.5,0.75))

# for deciles
quantile(v4,probs = seq(0.1,0.9,0.1))

# for percentiles 
quantile(v4,probs = seq(0.01,0.99,0.01))
quantile(v4,probs = c(0.15,0.55,0.86))


## Minimum and Maximum
v5 <- c(23,56,17,31,44,19)
v6 <- c(33,21,47,15,78,41)

v5;min(v5);max(v5)
v6;min(v6);max(v6)

## overall summary
v5;summary(v5)
v6;summary(v6)

## Variance and standard deviation
v5;var(v5);sd(v5)
v6;var(v6);sd(v6)

## covariance and correlation 
v5;v6;cov(v5,v6);cor(v5,v6)


## summation and product
v5;sum(v5);prod(v5)
v6;sum(v6);prod(v6)

## cumulative summation and product
v5;cumsum(v5);cumprod(v5)
v6;cumsum(v6);cumprod(v6)

## logarithm and exponential
v5;v7 <- log(v5);v7
v5;v8 <- log(v5,base = 3);v8
v5;v9 <- log(v5,3);v9
log(9,3)

v5;v7;exp(v7)

## square root 
sqrt(25)
v5;v9 <- sqrt(v5);v9

## Factorial and combination 
factorial(5)
choose(5,3)
v5;choose(v5,7)

## Absolute function
v10 <- c(45,-21,-32,11,-44)
v10;v11 <- abs(v10);v11

log(v10)
log(abs(v10))
sqrt(v10)
sqrt(abs(v10))

## Rounding number of decimals 
v9;round(v9)
v9;round(v9,digits = 1);round(v9,1)
v9;v12 <- round(v9,2);v12

## Solution for polynomial equations 
polyroot(c(-6,2))
as.numeric(polyroot(c(-6,2)))

polyroot(c(6,-5,1))
as.numeric(polyroot(c(6,-5,1)))

polyroot(c(-8, 2, 5, 1))
as.numeric(polyroot(c(-8, 2, 5, 1)))

v12 <- polyroot(c(-8, 2, 0, 1));class(v12)



